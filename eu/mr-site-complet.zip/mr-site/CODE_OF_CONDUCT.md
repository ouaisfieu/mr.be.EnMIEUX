# 📜 Code de Conduite

## Notre Engagement

Dans l'intérêt de favoriser un environnement ouvert et accueillant, nous nous engageons, en tant que contributeurs et mainteneurs, à faire de la participation à notre projet et à notre communauté une expérience exempte de harcèlement pour tous, quel que soit l'âge, la taille corporelle, le handicap, l'origine ethnique, l'identité et l'expression de genre, le niveau d'expérience, la nationalité, l'apparence personnelle, la race, la religion ou l'identité et l'orientation sexuelles.

## Nos Standards

### ✅ Comportements qui contribuent à créer un environnement positif :

- Utiliser un langage accueillant et inclusif
- Être respectueux des différents points de vue et expériences
- Accepter gracieusement les critiques constructives
- Se concentrer sur ce qui est le mieux pour la communauté
- Faire preuve d'empathie envers les autres membres de la communauté

### ❌ Comportements inacceptables :

- L'utilisation de langage ou d'images à caractère sexuel et les attentions ou avances sexuelles non désirées
- Le trolling, les commentaires insultants ou dégradants, et les attaques personnelles ou politiques
- Le harcèlement public ou privé
- La publication d'informations privées d'autrui, telles que des adresses physiques ou électroniques, sans permission explicite
- Tout autre comportement qui pourrait raisonnablement être considéré comme inapproprié dans un cadre professionnel

## Nos Responsabilités

Les mainteneurs du projet sont responsables de clarifier les standards de comportement acceptables et sont censés prendre des mesures correctives appropriées et justes en réponse à tout comportement inacceptable.

Les mainteneurs du projet ont le droit et la responsabilité de supprimer, éditer ou rejeter les commentaires, commits, code, modifications du wiki, issues et autres contributions qui ne sont pas alignés avec ce Code de Conduite, ou de bannir temporairement ou définitivement tout contributeur pour d'autres comportements qu'ils jugent inappropriés, menaçants, offensants ou nuisibles.

## Portée

Ce Code de Conduite s'applique à la fois dans les espaces du projet et dans les espaces publics lorsqu'un individu représente le projet ou sa communauté. Les exemples de représentation d'un projet ou d'une communauté incluent l'utilisation d'une adresse e-mail officielle du projet, la publication via un compte officiel sur les réseaux sociaux, ou le fait d'agir en tant que représentant désigné lors d'un événement en ligne ou hors ligne.

## Application

Les cas de comportement abusif, harcelant ou autrement inacceptable peuvent être signalés en contactant l'équipe du projet à [contact@mrenmieux.be]. Toutes les plaintes seront examinées et feront l'objet d'une enquête et donneront lieu à une réponse jugée nécessaire et appropriée aux circonstances. L'équipe du projet est tenue de maintenir la confidentialité à l'égard du rapporteur d'un incident. Plus de détails sur les politiques d'application spécifiques peuvent être publiés séparément.

Les mainteneurs du projet qui ne suivent pas ou n'appliquent pas le Code de Conduite de bonne foi peuvent faire face à des répercussions temporaires ou permanentes déterminées par les autres membres de la direction du projet.

## Attribution

Ce Code de Conduite est adapté du [Contributor Covenant][homepage], version 1.4, disponible à [https://www.contributor-covenant.org/fr/version/1/4/code-of-conduct.html][version]

[homepage]: https://www.contributor-covenant.org
[version]: https://www.contributor-covenant.org/fr/version/1/4/code-of-conduct.html

---

## 🤝 En Résumé

**Soyez gentil, respectueux et professionnel.** 

Nous sommes tous ici pour apprendre et créer ensemble. Toute contribution est la bienvenue, quelle que soit votre expérience ou votre background.

Si vous avez des questions ou des préoccupations, n'hésitez pas à contacter les mainteneurs.

**Merci de faire partie de notre communauté ! 💙**
