---
name: 💡 Feature Request
about: Proposer une nouvelle fonctionnalité ou amélioration
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## 💡 Description de la Fonctionnalité

Une description claire et concise de la fonctionnalité que vous souhaitez.

## 🤔 Problème Lié

La fonctionnalité est-elle liée à un problème ? Décrivez-le.

Ex. Je suis frustré quand [...]

## ✨ Solution Proposée

Une description claire de ce que vous voulez voir arriver.

## 🔄 Alternatives Considérées

Une description des solutions alternatives que vous avez envisagées.

## 📸 Maquettes / Exemples

Si applicable, ajoutez des maquettes, wireframes ou exemples d'autres sites.

## 📝 Contexte Additionnel

Ajoutez tout autre contexte ou captures d'écran concernant la fonctionnalité ici.

## 📋 Checklist

- [ ] J'ai vérifié que cette fonctionnalité n'a pas déjà été proposée
- [ ] J'ai décrit clairement le problème et la solution
- [ ] Cette fonctionnalité bénéficierait à d'autres utilisateurs
