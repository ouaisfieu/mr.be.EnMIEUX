---
name: 🐛 Bug Report
about: Signaler un bug pour nous aider à améliorer le projet
title: '[BUG] '
labels: bug
assignees: ''
---

## 🐛 Description du Bug

Une description claire et concise du bug.

## 📋 Pour Reproduire

Étapes pour reproduire le comportement :

1. Aller sur '...'
2. Cliquer sur '...'
3. Scroller jusqu'à '...'
4. Voir l'erreur

## ✅ Comportement Attendu

Une description claire de ce qui devrait se passer.

## 📸 Captures d'écran

Si applicable, ajoutez des captures d'écran pour aider à expliquer votre problème.

## 🖥️ Environnement

- **OS**: [ex. Windows 11, macOS Sonoma, Ubuntu 22.04]
- **Navigateur**: [ex. Chrome 120, Firefox 121, Safari 17]
- **Résolution**: [ex. 1920x1080, 375x667 (mobile)]

## 📝 Contexte Additionnel

Ajoutez tout autre contexte concernant le problème ici.

## 📋 Checklist

- [ ] J'ai vérifié que ce bug n'a pas déjà été signalé
- [ ] J'ai testé avec la dernière version du code
- [ ] J'ai fourni suffisamment d'informations pour reproduire le bug
