## 📝 Description

Une description claire et concise des changements apportés.

## 🔗 Issue Liée

Fixes #(numéro de l'issue)

## 🏷️ Type de Changement

Cochez les cases pertinentes :

- [ ] 🐛 Bug fix (changement non-breaking qui corrige un problème)
- [ ] ✨ Nouvelle fonctionnalité (changement non-breaking qui ajoute une fonctionnalité)
- [ ] 💥 Breaking change (changement qui casserait une fonctionnalité existante)
- [ ] 📚 Documentation (changements à la documentation uniquement)
- [ ] 🎨 Style (formatage, point-virgules manquants, etc; aucun changement de code)
- [ ] ♻️ Refactoring (changement de code qui ne corrige pas de bug ni n'ajoute de fonctionnalité)

## 🧪 Comment Cela a-t-il Été Testé ?

Décrivez les tests que vous avez effectués pour vérifier vos changements.

- [ ] Test A
- [ ] Test B

**Configuration de test** :
- Navigateur(s) : 
- OS : 
- Résolution(s) : 

## 📸 Captures d'Écran (si applicable)

| Avant | Après |
|-------|-------|
| screenshot | screenshot |

## 📋 Checklist

- [ ] Mon code suit les guidelines de style du projet
- [ ] J'ai effectué une self-review de mon code
- [ ] J'ai commenté mon code, particulièrement dans les zones difficiles à comprendre
- [ ] J'ai mis à jour la documentation si nécessaire
- [ ] Mes changements ne génèrent pas de nouveaux warnings
- [ ] J'ai testé sur mobile (< 768px)
- [ ] J'ai testé sur tablette (768px - 1024px)
- [ ] J'ai testé sur desktop (> 1024px)
- [ ] J'ai testé sur Chrome
- [ ] J'ai testé sur Firefox
- [ ] J'ai testé sur Safari (si possible)

## 📝 Notes pour les Reviewers

Ajoutez ici toute information supplémentaire pour aider les reviewers.
